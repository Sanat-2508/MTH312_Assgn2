# my_ecdf = function(dat, rand_points){
#   npoints = dim(dat)[1]  # number of data points
#   nrpoints = dim(rand_points)[1]
#   ndim = dim(dat)[2]      # dimension of points
#   cat(npoints, nrpoints, ndim, "\n")
#   res = numeric(length = nrpoints)
#   for(i in 1: nrpoints){
#     count = 0
#     for(j in 1:npoints){
#       check = sum(dat[, j] > rand_points[, i])
#       cat(check, "\n")
#       if(check == ndim){
#         count = count+1
#       }
#     }
#     res[i] = count/nrpoints
#   }
#   return (res)
# }
