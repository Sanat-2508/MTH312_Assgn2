########### Mean polynomial estimates ###########

mean_estimate_at_x0 <- function(x_0, h)
{
  # Function to optimize
  fn <- function(x_0, h, theta)
  {
    theta_0 <- theta[1]
    theta_1 <- theta[2]
    theta_2 <- theta[3]
    
    z <- y - theta_0 - (theta_1 * (x-x_0)) - (theta_2 * (x-x_0)^2) / 2
    z <- (z^2) * dnorm((x - x_0)/h)
    z <- sum(z) / n
    
    return(z)
  }
  
  # Finding m0, m1, m2 at x_0
  res <- optim(par = runif(3), fn = fn, 
               x_0 = x_0, h = h, method = "BFGS")
  par <- res$par
  return(par)
}

mean_polynomial_estimates <- function(n_points, from, to, h)
{
  # Finding mean estimates for m_0, m_1, m_2
  res <- matrix(data = 0, nrow = n_points, ncol = 3)
  grid_x <- seq(from = from, to = to, length = n_points)
  grid_x <- matrix(grid_x, nrow = n_points, ncol = 1)
  
  res <- apply(X = grid_x, MARGIN = 1, FUN = mean_estimate_at_x0, h = h)
}

######### Median polynomial estimates ###########

median_estimate_at_x0 <- function(x_0, h)
{
  # Function to optimize
  fn <- function(x_0, h, theta, eps = 0.01)
  {
    theta_0 <- theta[1]
    theta_1 <- theta[2]
    theta_2 <- theta[3]
    
    z <- y - theta_0 - (theta_1 * (x-x_0)) - (theta_2 * (x-x_0)^2) / 2
    z <- abs(z) * dnorm((x - x_0)/h)
    z <- (sum(z) / n) + eps
    # eps is added in order to prevent convergence issues
    
    return(z)
  }
  
  # Finding m0, m1, m2 at x_0
  res <- optim(par = runif(3), fn = fn, 
               x_0 = x_0, h = h, method = "BFGS")
  par <- res$par
  return(par)
}

median_polynomial_estimates <- function(n_points, from, to, h)
{
  # Finding mean estimates for m_0, m_1, m_2
  res <- matrix(data = 0, nrow = n_points, ncol = 3)
  grid_x <- seq(from = from, to = to, length = n_points)
  grid_x <- matrix(grid_x, nrow = n_points, ncol = 1)
  
  res <- apply(X = grid_x, MARGIN = 1, FUN = median_estimate_at_x0, h = h)
}

# Loading the dataset
data <- read.csv('canada_wage.csv')
data <- subset(data, select = c(logwage, age))
data <- data[complete.cases(data), ]

print(data[1:5, ])

y <- data[,1]
x <- data[,2]
n <- length(y)

plot(x = x, y = y, pch = 16,
     xlab = 'Age', ylab = 'Log Wage',
     main = 'Log(Wage) vs. Age in Canada')

# Finiding the estimates for various h
from <- min(x)
to <- max(x)
n_points <- 100
grid_x <- seq(from = from, to = to, length = n_points)

grid_h <- c(0.1, 0.5, 1, 5, 10)
mean_estimates <- list()
median_estimates <- list()

par(mfrow = c(1, 5))
print('Local polynomial mean estimates')

# Mean estimates
for(i in 1:length(grid_h))
{
  res <- mean_polynomial_estimates(n_points = n_points, 
                                   from = from, to = to, h = grid_h[i])
  mean_estimates[[i]] = res 
  print(paste('Mean Estimate' ,i, '/', length(grid_h)))
}

# Mean plots
for(i in 1:length(mean_estimates))
{
  plot(x = x, y = y, pch = 1,
       xlab = 'Age', ylab = 'Log Wage',
       main = paste('h = ', grid_h[i]))
  lines(x = grid_x, y = mean_estimates[[i]][1,],
        col = i, lwd = 3)
}

par(mfrow = c(1, 5))
print('Local polynomial median estimates')

# Median estimates
for(i in 1:length(grid_h))
{
  res <- median_polynomial_estimates(n_points = 100, 
                                     from = from, to = to, h = grid_h[i])
  median_estimates[[i]] = res
  print(paste('Median Estimate' ,i, '/', length(grid_h)))
}

# Median plots
for(i in 1:length(median_estimates))
{
  plot(x = x, y = y, pch = 1,
       xlab = 'Age', ylab = 'Log Wage',
       main = paste('Local polynomial median estimates ( h = ', grid_h[i], ')'))
  lines(x = grid_x, y = median_estimates[[i]][1,],
        col = i, lwd = 3)
}

# h = 5 seems to be the best choice for bandwidth. From the plots we can see 
# that for h <= 1, we over fit the given data. For h = 10, we get an over smooth
# curve. And we can see that h = 5 captures the data best.

par(mfrow = c(1, 1))

# Derivative plots
# Mean
plot(x = x, y = y, pch = 16,
     xlab = 'x', ylab = 'm(x)',
     main = 'Mean estimate ( h = 5 )')
lines(x = grid_x, y = mean_estimates[[4]][1, ],
      col = 2, lwd = 2)
plot(x = grid_x, y = mean_estimates[[4]][2, ],
     xlab = 'x', ylab = 'First derivative',
     main = 'Mean estimate First order derivate ( h = 5 )', 
     type = 'l', col = 2, lwd = 2)
plot(x = grid_x, y = mean_estimates[[4]][3, ],
     xlab = 'x', ylab = 'Second derivative',
     main = 'Mean estimate Second order derivate ( h = 5 )',
     type = 'l', col = 2, lwd = 2)

# Median
plot(x = x, y = y, pch = 16,
     xlab = 'x', ylab = 'm(x)',
     main = 'Median estimate ( h = 5 )')
lines(x = grid_x, y = median_estimates[[4]][1, ],
      col = 4, lwd = 2)
plot(x = grid_x, y = median_estimates[[4]][2, ],
     xlab = 'x', ylab = 'First derivative',
     main = 'Median estimate First order derivate ( h = 5 )', 
     type = 'l', col = 4, lwd = 2)
plot(x = grid_x, y = median_estimates[[4]][3, ],
     xlab = 'x', ylab = 'Second derivative',
     main = 'Median estimate Second order derivate ( h = 5 )',
     type = 'l', col = 4, lwd = 2)

# Comparison
mean_pred <- apply(X = matrix(data = x, ncol = 1), 
                   MARGIN = 1, FUN = mean_estimate_at_x0, h = 5)
# The first row of mean_pred contains the estimates of y
mean_pred <- mean_pred[1, ]
mean_error <- (1/n) * sum((y - mean_pred) ^ 2)

median_pred <- apply(X = matrix(data = x, ncol = 1), 
                   MARGIN = 1, FUN = median_estimate_at_x0, h = 5)
# The first row of median_pred contains the estimates of y
median_pred <- median_pred[1, ]
median_error <- (1/n) * sum((y - median_pred) ^ 2)

comparison <- matrix(data = c(mean_error, median_error),
                     nrow = 1, ncol = 2)
colnames(comparison) <- c('Mean estimator', 'Median Estimator')
comparison