########### Mean polynomial estimates ###########

mean_estimate_optim_fn <- function(x_0, h, theta)
{
  theta_0 <- theta[1]
  theta_1 <- theta[2]
  theta_2 <- theta[3]
  
  z <- y - theta_0 - (theta_1 * (x-x_0)) - (theta_2 * (x-x_0)^2) / 2
  z <- (z^2) * dnorm((x - x_0)/h)
  z <- sum(z) / n
  
  return(z)
}

mean_estimate_at_x0 <- function(x_0, h)
{
  res <- optim(par = runif(3), fn = mean_estimate_optim_fn, 
               x_0 = x_0, h = h, method = "BFGS")
  par <- res$par
  return(par)
}

mean_polynomial_estimates <- function(n_points = 500, from, to, h)
{
  # Finding mean estimates for m_0, m_1, m_2
  res <- matrix(data = 0, nrow = n_points, ncol = 3)
  grid_x <- seq(from = from, to = to, length = n_points)
  grid_x <- matrix(grid_x, nrow = n_points, ncol = 1)
  
  res <- apply(X = grid_x, MARGIN = 1, FUN = mean_estimate_at_x0, h = h)
  
  # Making plot
  plot(x = x, y = y, pch = 1,
       xlab = 'x', ylab = 'y', 
       main = paste('Mean polynomial estimate (h = ', h, ')'))
  lines(x = grid_x[,1], y = res[1,], col = 1, lwd = 2)
  lines(x = grid_x[,1], y = res[2,], col = 2, lwd = 2)
  lines(x = grid_x[,1], y = res[3,], col = 3, lwd = 2)
  legend('topleft', legend = c('m_0', 'm_1', 'm_2'),
         col = 1:3, lty = 1)
  return(res)
}

######### Median polynomial estimates ###########

median_estimate_optim_fn <- function(x_0, h, theta, eps = 0.01)
{
  theta_0 <- theta[1]
  theta_1 <- theta[2]
  theta_2 <- theta[3]
  
  z <- y - theta_0 - (theta_1 * (x-x_0)) - (theta_2 * (x-x_0)^2) / 2
  z <- abs(z) * dnorm((x - x_0)/h)
  z <- (sum(z) / n) + eps
  # eps is added in order to prevent convergence issues
  
  return(z)
}

median_estimate_at_x0 <- function(x_0, h)
{
  res <- optim(par = runif(3), fn = median_estimate_optim_fn, 
               x_0 = x_0, h = h, method = "BFGS")
  par <- res$par
  return(par)
}

median_polynomial_estimates <- function(n_points = 500, from, to, h)
{
  # Finding mean estimates for m_0, m_1, m_2
  res <- matrix(data = 0, nrow = n_points, ncol = 3)
  grid_x <- seq(from = from, to = to, length = n_points)
  grid_x <- matrix(grid_x, nrow = n_points, ncol = 1)
  
  res <- apply(X = grid_x, MARGIN = 1, FUN = median_estimate_at_x0, h = h)
  
  # Making plot
  plot(x = x, y = y, pch = 1,
       xlab = 'x', ylab = 'y', 
       main = paste('Median polynomial estimate (h = ', h, ')'))
  lines(x = grid_x[,1], y = res[1,], col = 1, lwd = 2)
  lines(x = grid_x[,1], y = res[2,], col = 2, lwd = 2)
  lines(x = grid_x[,1], y = res[3,], col = 3, lwd = 2)
  legend('topleft', legend = c('m_0', 'm_1', 'm_2'),
         col = 1:3, lty = 1)
  return(res)
}

# Data

n <- 100

x <- runif(n = n, min = 0, max = 5)
y <- exp(x) + rnorm(n = n, mean = 0, sd = 4)

grid_h <- c(0.1,0.5, 1, 5, 10)
mean_estimates <- list()
median_estimates <- list()

load(iris)


# 
# res <- mean_polynomial_estimates(n_points = 100, from = 0, to = 5, h = grid_h[i])
# mean_estimates[[i]] = res 
# 
# res <- median_polynomial_estimates(n_points = 100, from = 0, to = 5, h = grid_h[i])
# median_estimates[[i]] = res

# Mean estimates
for(i in 1:length(grid_h))
{
  res <- mean_polynomial_estimates(n_points = 100, from = 0, to = 5, h = grid_h[i])
  mean_estimates[[i]] = res

  res <- median_polynomial_estimates(n_points = 100, from = 0, to = 5, h = grid_h[i])
  median_estimates[[i]] = res
}
